﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameManagerScript : MonoBehaviour
{
    public static int Score;
    public GameObject txt_Score;
    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void AddScore()
    {
        Score++;
        txt_Score.GetComponent<TextMeshProUGUI>().text = "Score: " + Score;

        if (Score == 4)
        {
            LoadScene();
        }
    }
    public void LoadScene()
    {
        SceneManager.LoadScene(sceneBuildIndex: 2);
    }

    public void LoseScene()
    {
        SceneManager.LoadScene(sceneBuildIndex: 1);
    }
}
